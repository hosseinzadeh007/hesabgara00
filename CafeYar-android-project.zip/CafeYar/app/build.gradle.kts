plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ir.cafeyar"
    compileSdk = 34
    defaultConfig {
        applicationId = "ir.cafeyar.app"
        minSdk = 24
        targetSdk = 34
        versionCode = (project.findProperty("vCode") as String?)?.toIntOrNull() ?: 1
        versionName = (project.findProperty("vName") as String?) ?: "1.0"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.webkit:webkit:1.11.0") }

1) Android Studio > Open > پوشه CafeYar  (Sync Gradle را بزنید)
2) APK آزمایشی: Build > Build APK(s)   |   انتشار: Build > Generate Signed Bundle / APK
خروجی: app/build/outputs/apk/
